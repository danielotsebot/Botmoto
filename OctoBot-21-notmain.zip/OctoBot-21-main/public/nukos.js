const rejardNotez = "imongmamaw";
 document.getElementById("rejardNotez").textContent = rejardNotez; 