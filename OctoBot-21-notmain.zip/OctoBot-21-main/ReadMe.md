# Octobotv2.1

![logo](rejard/logo.jpg)

An Educational Messenger Bot Made with love aims to Help ppl for studies

<a style="font-size:27px" href="https://m.me/j/Abbl63EsX-6_NN7W/">JOIN ChatWithAi🤖</a>

## Developer Social Info

- **Facebook**: [https://facebook.com/rejardbentazarofficial](https://facebook.com/rejardbentazarofficial)

- **Facebook Page**: [https://facebook.com/61554405703021](https://facebook.com/61554405703021)


## Installation
 1. FORK and Ilisan mo yung Appstate, sa cookie.json
2. pwede mo din palitan using the WebView need mo lang ilagay ang appstate sa cookie.json tas upload 


## Issues 
1. Not Updated 🥴 Simple Bot
2. yung fca Palitan mo
3. update mo events ikaw na bahala batman🦀
4. encrypt mo index.html mo sa pagecrypt or use env para matago password ng admin panel

## Hmm.. para safe 
palitan mo ang endpoint ng upload sa line 92 (index.js) tsaka sa index.html nadin🥴 

## Admin Password (Default)
located at index.html sa <script> tag 
```text
rejardgwapodev69

```
## Live Demo
<a href="https://octobot-21.onrender.com/">https://octobot-21.onrender.com/</a>
## For more info don't be shy to talk to me🥴

