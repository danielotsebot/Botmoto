const axios = require('axios');
const fs = require('fs');

module.exports = async function ({ dstryr, event, parameters }) {
  try {
    
    const ownerInfo = `
      Owner: Daniel mojar
      FB: https://fb.com/61554405703021
      Github: https://github.com/LeechShares
      FbPage: none
    `;

    dstryr.sendMessage(ownerInfo, event.threadID);
     
  } catch (error) {
    console.error(error);
    dstryr.sendMessage('error pre mali siguro ang typo mo.', event.threadID);
  }
};
